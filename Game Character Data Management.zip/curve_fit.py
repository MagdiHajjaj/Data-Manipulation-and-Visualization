# ECOR 1042 Lab 6 - Template for curve_fit function

# Remember to include docstring and type annotations for your functions

# Update "" with your name (e.g., Cristina Ruiz Martin)
__author__ = "Magdi Hajjaj"

# Update "" with your student number (e.g., 100100100)
__student_number__ = "101299841"

# Update "" with your team (e.g. T-102, use the notation provided in the example)
__team__ = "T-002"

#==========================================#
# Place your curve_fit function after this line


# Do NOT include a main script in your submission



